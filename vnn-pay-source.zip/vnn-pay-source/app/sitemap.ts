import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = "https://vnnpay.org";
  return ["", "/privacy", "/refund", "/security", "/terms", "/compliance", "/sitemap"].map((path) => ({
    url: `${baseUrl}${path}`,
    lastModified: new Date("2026-08-13"),
    changeFrequency: path === "" ? "weekly" : "monthly",
    priority: path === "" ? 1 : 0.7,
  }));
}
