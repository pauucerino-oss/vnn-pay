import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://vnnpay.org"),
  title: {
    default: "VNN Pay — Build your U.S. presence from Vietnam",
    template: "%s",
  },
  description:
    "Moving money is only the beginning. VNN Pay helps Vietnam-based businesses establish, organize, and grow a stronger digital presence in the United States.",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
  openGraph: {
    type: "website",
    locale: "vi_VN",
    siteName: "VNN Pay",
    title: "VNN Pay — Moving money is only the beginning.",
    description: "Build a stronger digital presence in the United States — from Vietnam.",
    images: [{ url: "/og.png", width: 1200, height: 630, alt: "VNN Pay — From Vietnam to a stronger U.S. presence." }],
  },
  twitter: {
    card: "summary_large_image",
    title: "VNN Pay — Moving money is only the beginning.",
    description: "Build a stronger digital presence in the United States — from Vietnam.",
    images: ["/og.png"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="vi">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
