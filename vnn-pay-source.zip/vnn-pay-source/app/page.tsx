import type { Metadata } from "next";
import Link from "next/link";
import { SiteFooter, SiteHeader } from "./_components/site-shell";

export const metadata: Metadata = {
  title: "VNN Pay — Build your U.S. presence from Vietnam",
  description:
    "Moving money is only the beginning. VNN Pay helps Vietnam-based businesses establish, organize, and grow a stronger digital presence in the United States.",
};

const activities = [
  { name: "Business profile", ref: "Information added", value: "Ready", tone: "mint" },
  { name: "Channel checklist", ref: "Four items organized", value: "4 / 5", tone: "blue" },
  { name: "Customer follow-ups", ref: "Planned for this week", value: "03", tone: "sand" },
];

const merchantTypes = ["Export-ready brands", "Studio & agency", "SaaS & digital services", "E-commerce sellers", "Vietnam-founded teams"];

export default function Home() {
  return (
    <main>
      <SiteHeader />

      <section className="hero section-shell" id="san-pham">
        <div className="hero-copy">
          <div className="eyebrow"><span /> Vietnam → United States · Early Access</div>
          <h1>Moving money<br />is only <em>the beginning.</em></h1>
          <p className="hero-lede">
            VNN Pay helps Vietnam-based businesses establish, organize, and grow
            a stronger digital presence in the United States.
          </p>
          <div className="hero-actions">
            <a className="button button-primary" href="#dang-ky">Build your U.S. presence <span>↗</span></a>
            <a className="button button-quiet" href="#cach-hoat-dong">See how it works <span>↓</span></a>
          </div>
          <div className="micro-trust" aria-label="Lợi ích chính">
            <span><i>✓</i> Vietnam-first support</span>
            <span><i>✓</i> One organized workspace</span>
            <span><i>✓</i> Clear legal boundaries</span>
          </div>
        </div>

        <div className="product-stage" aria-label="Bản xem trước bảng điều khiển VNN Pay">
          <div className="stage-orbit orbit-one" />
          <div className="stage-orbit orbit-two" />
          <div className="dashboard-window">
            <aside className="dash-sidebar">
              <div className="mini-mark"><b>V</b></div>
              <nav aria-label="Menu ứng dụng minh họa">
                <span className="active"><i>01</i> U.S. Overview</span>
                <span><i>02</i> Presence</span>
                <span><i>03</i> Customers</span>
                <span><i>04</i> Money</span>
              </nav>
              <div className="sidebar-account"><span>NT</span><small>Nam Trần<br /><b>Admin</b></small></div>
            </aside>
            <div className="dash-main">
              <div className="dash-topbar">
                <div><small>ILLUSTRATIVE PRODUCT CONCEPT</small><h2>Good morning, Nam.</h2></div>
                <button type="button">+ Add next step</button>
              </div>
              <div className="metric-grid">
                <article className="metric metric-featured">
                  <small>Roadmap progress</small>
                  <strong>04 / 05</strong>
                  <span>One foundation step remains</span>
                  <div className="mini-bars" aria-hidden="true">
                    {[28, 36, 31, 52, 44, 68, 62, 78, 70, 92].map((height, index) => <i key={index} style={{ height: `${height}%` }} />)}
                  </div>
                </article>
                <article className="metric"><small>Workspace areas</small><strong>04</strong><span className="status-good">● Information added</span></article>
                <article className="metric"><small>Next steps</small><strong>03</strong><span>Due this week</span></article>
              </div>
              <div className="transaction-card">
                <div className="card-heading"><div><small>U.S. PRESENCE</small><h3>What is moving forward</h3></div><span>View roadmap →</span></div>
                <div className="transaction-list">
                  {activities.map((activity) => (
                    <div className="transaction-row" key={activity.name}>
                      <span className={`avatar ${activity.tone}`}>{activity.name.split(" ").slice(0, 2).map(word => word[0]).join("")}</span>
                      <span className="transaction-name"><b>{activity.name}</b><small>{activity.ref}</small></span>
                      <span className="paid-tag">On track</span>
                      <strong>{activity.value}</strong>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div className="stage-note note-top"><span>✓</span><div><b>Profile draft is ready</b><small>Business information organized</small></div></div>
          <div className="stage-note note-bottom"><small>MARKET READINESS</small><b>4 of 5</b><span>One step to complete</span></div>
        </div>
      </section>

      <section className="principles-bar" aria-label="Nguyên tắc sản phẩm">
        <div className="section-shell principle-grid">
          <span className="principle-intro">Không chỉ chuyển tiền.<br /><b>Một nền tảng cho hành trình vào thị trường Mỹ.</b></span>
          <span><i>01</i><b>Establish</b><small>Thiết lập nền tảng số rõ ràng.</small></span>
          <span><i>02</i><b>Organize</b><small>Gom vận hành về một nơi.</small></span>
          <span><i>03</i><b>Grow</b><small>Được tìm thấy và tin tưởng.</small></span>
        </div>
      </section>

      <section className="section-shell feature-intro" id="giai-phap">
        <div className="section-label">01 — ESTABLISH · ORGANIZE · GROW</div>
        <div className="split-heading">
          <h2>Một nơi để xây hiện diện.<br /><em>Một nhịp để phát triển.</em></h2>
          <p>Từ nền móng digital đến hoạt động thường ngày và tăng trưởng thị trường, VNN Pay giúp đội ngũ tại Việt Nam giữ mọi bước đi tại Hoa Kỳ có tổ chức.</p>
        </div>
        <div className="feature-grid">
          <article className="feature-card feature-large">
            <div className="feature-number">01</div>
            <div className="link-demo foundation-demo">
              <div className="link-demo-top"><span>U.S. MARKET FOUNDATION</span><b>03 / 05</b></div>
              <div className="foundation-route"><span>VN</span><i /><span>US</span></div>
              <div className="foundation-list"><span><i>✓</i><b>Business profile</b><small>Ready</small></span><span><i>✓</i><b>Brand identity</b><small>Ready</small></span><span><i>→</i><b>U.S. channels</b><small>Next</small></span></div>
            </div>
            <h3>Establish a clearer foundation.</h3>
            <p>Biến mục tiêu “vào thị trường Mỹ” thành một lộ trình rõ: business profile, brand presence, kênh số và những bước cần hoàn thiện.</p>
          </article>
          <article className="feature-card feature-stack">
            <div className="feature-number">02</div>
            <div className="pulse-list" aria-hidden="true"><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /></div>
            <h3>Organize every moving part.</h3>
            <p>Quản lý hồ sơ, nội dung, khách hàng, payment activity và đầu việc trong một workspace — thay vì rải rác qua nhiều công cụ.</p>
          </article>
          <article className="feature-card feature-stack feature-ink">
            <div className="feature-number">03</div>
            <div className="customer-stack" aria-hidden="true">
              <span><i className="mint">SE</i><b>Search presence</b><small>Information added</small></span>
              <span><i className="blue">TR</i><b>Trust checklist</b><small>4 items organized</small></span>
              <span><i className="sand">US</i><b>Customer workflow</b><small>3 follow-ups planned</small></span>
            </div>
            <h3>Build toward a presence people trust.</h3>
            <p>Củng cố khả năng được tìm thấy, tính nhất quán thương hiệu và mối quan hệ với khách hàng — với tiến độ nhìn thấy được.</p>
          </article>
        </div>
      </section>

      <section className="how-section" id="cach-hoat-dong">
        <div className="section-shell">
          <div className="section-label light">02 — YOUR U.S. PRESENCE, STEP BY STEP</div>
          <div className="how-heading"><h2>Từ tham vọng đến hiện diện.<br /><em>Từng bước đều rõ ràng.</em></h2><p>VNN Pay chuyển một hành trình phức tạp thành roadmap dễ hiểu, có trạng thái và có người hỗ trợ bằng tiếng Việt.</p></div>
          <div className="steps">
            <article><span>01</span><div className="step-visual business-card"><i>VN</i><b>Mộc Nhiên Studio</b><small>U.S. presence roadmap</small><em>Discovery complete</em></div><h3>Establish the foundation</h3><p>Xác định mục tiêu, khách hàng, footprint hiện tại và những thành phần digital cần xây — không ngầm thay thế tư vấn pháp lý hay thuế.</p></article>
            <article><span>02</span><div className="step-visual amount-card"><small>WORKSPACE READINESS</small><b>04 / 05</b><i>+ Connect a U.S. channel</i></div><h3>Organize the operation</h3><p>Đưa hồ sơ, brand assets, kênh bán, customer follow-ups và payment activity về cùng một hệ thống.</p></article>
            <article><span>03</span><div className="step-visual success-card"><i>↗</i><b>Next growth action ready</b><small>Roadmap progress · 04 / 05</small></div><h3>Grow with confidence</h3><p>Ưu tiên việc có tác động, theo dõi tiến độ và củng cố mức độ hiện diện, nhất quán và đáng tin cậy tại Hoa Kỳ.</p></article>
          </div>
        </div>
      </section>

      <section className="security-section section-shell" id="bao-mat">
        <div className="security-copy">
          <div className="section-label">03 — NIỀM TIN ĐƯỢC THIẾT KẾ</div>
          <h2>Vươn ra thị trường mới.<br /><em>Không đánh đổi niềm tin.</em></h2>
          <p>VNN Pay đặt quyền riêng tư, khả năng kiểm soát và ranh giới trách nhiệm vào từng quyết định — đặc biệt khi dữ liệu và hoạt động đi qua hai thị trường.</p>
          <Link className="text-link" href="/security">Xem nguyên tắc bảo mật <span>↗</span></Link>
        </div>
        <div className="security-console">
          <div className="console-top"><span>VNN PAY / TRUST CENTER</span><i>TRẠNG THÁI: EARLY ACCESS</i></div>
          <div className="console-score"><div><small>NGUYÊN TẮC</small><b>Security<br />by design</b></div><span>01</span></div>
          <div className="console-grid">
            <article><span>01</span><b>Giảm thiểu dữ liệu</b><small>Chỉ thu thập dữ liệu cần cho mục đích đã công bố.</small></article>
            <article><span>02</span><b>Mã hóa & phân quyền</b><small>Bảo vệ dữ liệu khi truyền và giới hạn quyền truy cập.</small></article>
            <article><span>03</span><b>Giám sát có trách nhiệm</b><small>Theo dõi rủi ro và có quy trình phản hồi sự cố.</small></article>
            <article><span>04</span><b>Đối tác được thẩm định</b><small>Đánh giá nhà cung cấp tại Việt Nam và Hoa Kỳ trước khi tích hợp.</small></article>
          </div>
          <p className="console-note">VNN Pay Early Access chưa xử lý tiền và không cung cấp tư vấn pháp lý, thuế hay di trú. Dịch vụ có điều kiện chỉ được triển khai sau khi đánh giá yêu cầu tại Việt Nam, Hoa Kỳ và/hoặc qua đối tác phù hợp.</p>
        </div>
      </section>

      <section className="merchant-section">
        <div className="section-shell merchant-grid">
          <div>
            <div className="section-label">04 — BUILT IN VIETNAM. READY FOR MORE.</div>
            <h2>Bạn hiểu sản phẩm.<br /><em>VNN Pay giúp xây cây cầu.</em></h2>
          </div>
          <div className="merchant-copy">
            <p>Dành cho đội ngũ tại Việt Nam đã có sản phẩm hoặc năng lực thật và muốn hiện diện chuyên nghiệp hơn trước khách hàng Hoa Kỳ — không cần tự ghép hàng chục công cụ.</p>
            <div className="merchant-tags">{merchantTypes.map(type => <span key={type}>{type} <i>↗</i></span>)}</div>
          </div>
        </div>
      </section>

      <section className="faq-section section-shell" id="faq">
        <div className="faq-heading"><div className="section-label">05 — CÂU HỎI THƯỜNG GẶP</div><h2>Rõ trước khi đi xa.</h2><p>VNN Pay nói rõ điều sản phẩm hướng tới, điều chưa làm và ranh giới với chuyên gia được cấp phép.</p></div>
        <div className="faq-list">
          <details open><summary>“Digital presence tại Hoa Kỳ” gồm những gì?<span>+</span></summary><p>Đó là cách doanh nghiệp được tìm thấy, được hiểu và được tin tưởng: business profile, website và brand consistency, kênh tiếp cận, customer workflow, payment activity cùng một roadmap vận hành rõ ràng.</p></details>
          <details><summary>VNN Pay có thành lập công ty Mỹ thay tôi không?<span>+</span></summary><p>Không ở giai đoạn Early Access. VNN Pay giúp tổ chức hành trình và có thể kết nối nhà cung cấp phù hợp, nhưng không cung cấp tư vấn pháp lý, thuế hoặc di trú và không bảo đảm việc đăng ký pháp nhân, EIN, tài khoản ngân hàng hay phê duyệt của nền tảng bên thứ ba.</p></details>
          <details><summary>VNN Pay hiện đã xử lý giao dịch thật chưa?<span>+</span></summary><p>Chưa. Moving money là một phần của định hướng dài hạn, nhưng giao dịch thật chỉ được kích hoạt sau khi mô hình vận hành, đối tác và yêu cầu pháp lý tại các thị trường liên quan đã sẵn sàng.</p></details>
          <details><summary>Ai phù hợp tham gia Early Access?<span>+</span></summary><p>Brand, studio, agency, SaaS, đội ngũ dịch vụ và nhà bán hàng đang hoạt động tại Việt Nam, đã có giá trị thật để cung cấp và muốn xây sự hiện diện có tổ chức hơn tại Hoa Kỳ.</p></details>
          <details><summary>Tham gia danh sách có mất phí không?<span>+</span></summary><p>Không. Đăng ký Early Access miễn phí và không tạo nghĩa vụ sử dụng. Mọi mức phí tương lai sẽ được công bố rõ trước khi merchant kích hoạt dịch vụ.</p></details>
        </div>
      </section>

      <section className="cta-section" id="dang-ky">
        <div className="section-shell cta-inner">
          <div className="cta-copy"><span>VIETNAM → UNITED STATES · EARLY ACCESS</span><h2>Your U.S. presence<br /><em>should grow with you.</em></h2><p>Kể VNN Pay nghe bạn đang xây gì tại Việt Nam và muốn đạt điều gì tại Hoa Kỳ. Chúng tôi sẽ dùng câu trả lời để định hình nhóm thử nghiệm phù hợp.</p></div>
          <div className="cta-card">
            <small>BƯỚC ĐẦU TIÊN</small>
            <h3>Start your U.S. presence roadmap</h3>
            <p>Gửi email ngắn về doanh nghiệp, mục tiêu tại Hoa Kỳ, footprint hiện tại và rào cản lớn nhất của bạn.</p>
            <a className="button button-primary button-full" href="mailto:hello@vnnpay.org?subject=VNN%20Pay%20Early%20Access%20%E2%80%94%20U.S.%20Presence&body=T%C3%AAn%20doanh%20nghi%E1%BB%87p%3A%0AS%E1%BA%A3n%20ph%E1%BA%A9m%20%2F%20d%E1%BB%8Bch%20v%E1%BB%A5%3A%0AM%E1%BB%A5c%20ti%C3%AAu%20t%E1%BA%A1i%20Hoa%20K%E1%BB%B3%3A%0AHi%E1%BB%87n%20di%E1%BB%87n%20hi%E1%BB%87n%20t%E1%BA%A1i%3A%0AR%C3%A0o%20c%E1%BA%A3n%20l%E1%BB%9Bn%20nh%E1%BA%A5t%3A">Tell us what you’re building <span>↗</span></a>
            <span className="privacy-note">Bằng cách liên hệ, bạn đồng ý để VNN Pay phản hồi theo <Link href="/privacy">Chính sách quyền riêng tư</Link>.</span>
          </div>
        </div>
      </section>

      <SiteFooter />
    </main>
  );
}
