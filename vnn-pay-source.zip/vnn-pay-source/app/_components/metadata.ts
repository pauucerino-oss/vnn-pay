import type { Metadata } from "next";

export function detailMetadata(title: string, description: string): Metadata {
  return {
    title,
    description,
    openGraph: { title, description, images: [] },
    twitter: { title, description, images: [] },
  };
}
