import type { ReactNode } from "react";
import Link from "next/link";
import { SiteFooter, SiteHeader } from "./site-shell";

export type PolicySection = {
  title: string;
  content: ReactNode;
};

type PolicyLayoutProps = {
  code: string;
  title: string;
  intro: string;
  sections: PolicySection[];
  notice?: ReactNode;
};

const policyLinks = [
  ["/privacy", "Quyền riêng tư"],
  ["/refund", "Hoàn tiền"],
  ["/security", "Bảo mật"],
  ["/terms", "Điều khoản"],
  ["/compliance", "Tuân thủ"],
];

export function PolicyLayout({ code, title, intro, sections, notice }: PolicyLayoutProps) {
  return (
    <main className="policy-page">
      <SiteHeader />
      <section className="policy-hero">
        <div className="section-shell">
          <div className="policy-code">TRUST CENTER / {code}</div>
          <h1>{title}</h1>
          <p>{intro}</p>
          <div className="policy-meta"><span>Cập nhật: 13/08/2026</span><span>Phiên bản Early Access 1.0</span></div>
        </div>
      </section>
      <div className="section-shell policy-layout">
        <aside className="policy-aside">
          <b>TRUST CENTER</b>
          <nav aria-label="Các chính sách VNN Pay">
            {policyLinks.map(([href, label]) => <Link className={code.toLowerCase().includes(href.slice(1)) ? "active" : ""} key={href} href={href}>{label}<span>↗</span></Link>)}
          </nav>
          <a className="policy-contact" href="mailto:hello@vnnpay.org"><small>CẦN TRAO ĐỔI?</small><b>hello@vnnpay.org</b><span>↗</span></a>
        </aside>
        <article className="policy-content">
          {notice && <div className="legal-notice"><span>i</span><div>{notice}</div></div>}
          <div className="policy-toc"><b>NỘI DUNG</b>{sections.map((section, index) => <a href={`#muc-${index + 1}`} key={section.title}><span>{String(index + 1).padStart(2, "0")}</span>{section.title}</a>)}</div>
          {sections.map((section, index) => (
            <section id={`muc-${index + 1}`} key={section.title}>
              <span className="section-index">{String(index + 1).padStart(2, "0")}</span>
              <h2>{section.title}</h2>
              <div>{section.content}</div>
            </section>
          ))}
          <div className="policy-end"><span>VNN PAY / {code}</span><b>Hết tài liệu</b></div>
        </article>
      </div>
      <SiteFooter />
    </main>
  );
}

export function Paragraphs({ children }: { children: ReactNode }) {
  return <div className="policy-prose">{children}</div>;
}
