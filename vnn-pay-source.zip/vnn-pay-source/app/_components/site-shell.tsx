import Link from "next/link";

export function Brand() {
  return <Link className="brand" href="/" aria-label="VNN Pay — Trang chủ"><span className="brand-symbol"><i>V</i></span><b>VNN</b><em>PAY</em></Link>;
}

export function SiteHeader() {
  return (
    <header className="site-header">
      <div className="header-inner section-shell">
        <Brand />
        <nav className="desktop-nav" aria-label="Điều hướng chính">
          <a href="/#san-pham">Sản phẩm</a>
          <a href="/#giai-phap">Giải pháp</a>
          <a href="/#bao-mat">Bảo mật</a>
          <a href="/#faq">Tài nguyên</a>
        </nav>
        <a className="header-cta" href="/#dang-ky">Đăng ký sớm <span>↗</span></a>
        <details className="mobile-nav">
          <summary aria-label="Mở menu"><i /><i /></summary>
          <div>
            <a href="/#san-pham">Sản phẩm</a>
            <a href="/#giai-phap">Giải pháp</a>
            <a href="/#bao-mat">Bảo mật</a>
            <a href="/#faq">Tài nguyên</a>
            <a href="/#dang-ky">Đăng ký Early Access ↗</a>
          </div>
        </details>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="section-shell footer-top">
        <div className="footer-brand"><Brand /><p>From Vietnam to a stronger<br />digital presence in the United States.</p></div>
        <div className="footer-column"><b>SẢN PHẨM</b><a href="/#giai-phap">Establish · Organize · Grow</a><a href="/#cach-hoat-dong">Cách hoạt động</a><a href="/#bao-mat">Trust Center</a><a href="/#dang-ky">Early Access</a></div>
        <div className="footer-column"><b>TRUST CENTER</b><Link href="/security">Security Policy</Link><Link href="/privacy">Privacy Policy</Link><Link href="/compliance">Compliance</Link><Link href="/refund">Refund Policy</Link></div>
        <div className="footer-column"><b>PHÁP LÝ</b><Link href="/terms">Terms / Legal</Link><Link href="/sitemap">Sitemap</Link><a href="mailto:hello@vnnpay.org">hello@vnnpay.org</a></div>
      </div>
      <div className="section-shell footer-bottom"><span>© 2026 VNN Pay. Early Access.</span><span>Built for Vietnam-based businesses going further <i>●</i> vnnpay.org</span></div>
    </footer>
  );
}
