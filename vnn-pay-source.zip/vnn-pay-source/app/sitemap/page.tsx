import Link from "next/link";
import { SiteFooter, SiteHeader } from "../_components/site-shell";
import { detailMetadata } from "../_components/metadata";

export const metadata = detailMetadata("Sitemap — VNN Pay", "Sơ đồ nội dung website VNN Pay.");

const groups = [
  { code: "01", title: "Trang chính", links: [["/", "Landing page"], ["/#giai-phap", "Giải pháp"], ["/#cach-hoat-dong", "Cách hoạt động"], ["/#faq", "Câu hỏi thường gặp"], ["/#dang-ky", "Đăng ký Early Access"]] },
  { code: "02", title: "Trust Center", links: [["/security", "Security Policy"], ["/privacy", "Privacy Policy"], ["/compliance", "Compliance"], ["/refund", "Refund Policy"]] },
  { code: "03", title: "Pháp lý", links: [["/terms", "Terms / Legal"], ["/sitemap", "Sitemap"], ["mailto:legal@vnnpay.org", "Liên hệ pháp lý"]] },
];

export default function SitemapPage() {
  return (
    <main className="sitemap-page">
      <SiteHeader />
      <section className="sitemap-hero section-shell"><div className="section-label">VNNePAY.ORG / SITEMAP</div><h1>Một website nhỏ.<br /><em>Mọi thông tin cần thiết.</em></h1><p>Cấu trúc được giữ gọn để merchant tìm sản phẩm, hiểu niềm tin và kiểm tra chính sách mà không lạc trong quá nhiều menu.</p></section>
      <section className="sitemap-grid section-shell">
        {groups.map(group => <article key={group.code}><span>{group.code}</span><h2>{group.title}</h2><div>{group.links.map(([href, label]) => href.startsWith("mailto") ? <a href={href} key={href}>{label}<i>↗</i></a> : <Link href={href} key={href}>{label}<i>↗</i></Link>)}</div></article>)}
      </section>
      <section className="sitemap-note section-shell"><b>Giai đoạn tiếp theo</b><p>Khi sản phẩm trưởng thành, website có thể mở rộng thêm Pricing, Help Center và trang trạng thái hệ thống. Chỉ thêm khi merchant thực sự cần.</p></section>
      <SiteFooter />
    </main>
  );
}
